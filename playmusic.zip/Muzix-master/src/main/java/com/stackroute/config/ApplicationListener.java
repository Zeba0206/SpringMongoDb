package com.stackroute.config;

import com.stackroute.domain.Track;
import com.stackroute.repository.TrackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.jboss.logging.Logger;

//import java.util.logging.Logger;

@Component
public class ApplicationListener implements org.springframework.context.ApplicationListener {
    private static final Logger logs = Logger.getLogger(ApplicationListener.class);
    private TrackRepository trackRepository;

    @Autowired
    public ApplicationListener(TrackRepository trackRepository){

        this.trackRepository=trackRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent){
        logs.info("Inserting data on start");



        Track trackOne = new Track(5,"When the night is over","Singer : Lord Huron");
        trackRepository.save(trackOne);
        Track trackTwo = new Track(6,"High on life","Singer : Bonn");
        trackRepository.save(trackTwo);

        logs.info("data successfully inserted");
    }
}
