# Muzix




Muzix is an online application that helps users manage music listed on Music Database.
Using this app, a user should be able to search and manage music

  - Save track information
  - Display saved track
  - Update comments of saved track
  - Remove track



### Tech

Muzix uses a number of open source projects to work properly:

* [Spring] 
* [Spring Boot] 
* [Tomcat] 
* [Swagger] 
* [mysql] 
* [h2] 
* [Java]

